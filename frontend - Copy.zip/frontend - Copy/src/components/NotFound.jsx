import React from 'react'

const NotFound = () => {
  return (
      <div className="overlay">
      <h1>Página no existente, volvamos a intentarlo: <a href="/">Click aquí para volver a la página de Inicio</a>
      </h1>
    </div>

  )
}

export default NotFound
