import React from 'react'

const Profile = () => {
  return (
    <div>
      <p> Usuario: juanito@gmail.com</p>
      <p><button>Cerrar Sesión</button></p>
    </div>
  )
}

export default Profile
